# Handoff: Sutra — document workspace (UI/UX redesign)

## Overview
Sutra is a local-first, instant document workspace (Tauri shell + webview UI) that opens Markdown, PDF, Word, PowerPoint, Excel, HTML and text — read like a book, edit like Notion, all offline. This package delivers the redesigned UI/UX: the tabbed reader/editor, per-format modes, the Projects/library system, the AI companion, a unified icon set, a themeable token layer, and the mobile layout.

## About the Design Files
The files in this bundle are **design references authored in HTML** (Design Components) — interactive prototypes that show intended look and behavior. They are **not production code to paste in**. The task is to **recreate these designs inside Sutra's existing environment** — the hand-built CSS + CSS-variable theme layer described in the product's own spec (`--bg`, `--panel`, `--border`, `--fg`, `--text-muted`, `--accent`, `--hover`, `--ok`) — using the app's established patterns. Do not introduce a new design-system framework. Where this doc names an inline hex, map it to the corresponding theme variable rather than hard-coding it.

Two files:
- **`Sutra Prototype.dc.html`** — the **working, interactive** prototype (tabs, modes, ⌘K palette, editor with slash menu + selection bubble, AI panel with streaming, 5 live themes, desktop + iPhone mobile view). This is the primary behavioral reference.
- **`Aurora Editor.dc.html`** — the **static hi-fi comps** (canvas of design options, turns 1–5): the three original directions, the redesigned editor screens, the home/projects dashboard, sidebar treatment, icon-set + token sheet, the new-project sheet, export dialog, PPTX presentation mode, editor slash-menu detail, and the knowledge graph. Use as the visual source of truth for surfaces the working prototype doesn't yet include.

> To open a `.dc.html` file as plain reference, view it in a browser; the design renders immediately. Ignore the `support.js`/`<x-dc>` scaffolding — it's the prototype runtime, not part of the design.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, iconography, and interactions are specified. Recreate the UI pixel-accurately using Sutra's existing CSS-variable layer and component conventions. The one deliberate abstraction: the prototype's "device frame" and "Desktop/Mobile" preview toggle are **presentation chrome for review only** — do not build them; the real app is desktop when the window is wide and switches to the mobile layout at ≤720px.

---

## Design Tokens

### Theme variables (one block per theme — the app already works this way)
Every surface is expressed in these. Values below for the two reference themes; the other eight (System, GitHub Light, Dracula, Solarized Light/Dark, Monokai, One Dark, Nord) follow the same keys.

| Token | Role | Sepia | One Dark |
|---|---|---|---|
| `--bg` | content background | `#f4eee2` | `#282c34` |
| `--panel` | bars / chrome | `#ece3d2` | `#21252b` |
| `--panel2` | secondary chrome (sidebar) | `#efe6d6` | `#2c313a` |
| `--border` | hairlines | `#e2d8c5` | `#3a3f4b` |
| `--fg` | primary text | `#3a322a` | `#c5ccd6` |
| `--text-muted` | secondary text | `#8a7f6d` | `#7a828e` |
| `--accent` | brand / active | `#b5623a` | `#61afef` |
| `--accent-fg` | text on accent | `#ffffff` | `#0b0d10` |
| `--hover` | hover fill | `#e7dcc7` | `#2f353f` |
| `--ok` | success / saved | `#3f8f5a` | `#98c379` |
| `--code-bg` | inline/code block | `#f0e8d9` | `#2c313a` |
| `--card` | raised card/doc | `#faf5ea` | `#2c313a` |

(The prototype uses `--accentFg`/`--codeBg`; map to your existing naming, e.g. `--accent-fg`/`--code-bg`.)

### Project palette (fixed hues; desaturate ~15% on dark themes so they never clash)
`#b5623a` terracotta · `#4f8a80` teal · `#5a6bb0` indigo · `#8a5a80` plum · `#7a8a4a` olive · `#c8912a` amber · `#c05a4a` red · `#4a7ba6` blue

### Format-badge colors (rounded square, white mono label, `Geist Mono` 700)
MD `#b5623a` · HTML `#5a86b0` · PDF `#c05a4a` · DOC `#2f6fb0` · PPT `#c8912a` · XLS `#3f8f5a` · TXT `#8a7f6d`
Badge sizes: 16px in tabs (7px text), 20–22px in trees (7–8px), 30–34px in lists/home (9–10px). Radius 4–9px scaling with size.

### Typography
- **UI / body:** `Hanken Grotesk` (system-ui fallback). Body 16.5px / line-height 1.7. UI text 11.5–13px.
- **Reading headings & editorial:** `Newsreader` serif. H1 38px/1.14 wt 600, H2 26px wt 600, H3 18px wt 700. Italic Newsreader for metadata lines and blockquotes.
- **Mono:** `Geist Mono` — code, file badges, keyboard hints, path segments. 10–13px.
- Serif/Sans/Mono are also user-selectable **reading fonts** (view setting, not saved into the file).
- Letter-spacing: section labels `.09em` uppercase 10.5–11px wt 700 in `--text-muted`.

### Spacing / radius / shadow
- Radius: buttons/chips 7–9px, cards/panels 11–16px, modals 16–20px, pills 20px, FAB/phone 17–46px.
- Icon buttons: 34×34px hit target (44px min on mobile), 9px radius, `--text-muted`, hover fill `--hover`.
- Elevation: menus/popovers `0 20px 44px -16px rgba(0,0,0,.4)`; modals `0 40px 90px -30px rgba(50,30,10,.6)`; toast `0 14px 34px -12px`.
- Motion (restrained): pop-in `0 .13s ease-out` (translateY 6px + scale .98→1); sheet slide `.22s cubic-bezier(.22,1,.36,1)`; fade `.15s`; blinking AI caret `1s steps(1)`. Progress/width transitions `.3s`.

### Iconography — one stroke family, NO emoji
24×24 grid, `fill:none`, `stroke:currentColor`, **stroke-width 1.6** (1.7 for small chrome), round caps/joins. Recolors via `currentColor` for free across themes. The AI "sparkle" is the only **filled** glyph (4-point star `M12 2l1.9 6.1L20 10l-6.1 1.9L12 18l-1.9-6.1L4 10l6.1-1.9z`). Core set (paths in `Aurora Editor.dc.html` §3c and reused throughout `Sutra Prototype.dc.html`'s `icon()` map): home, files/folder, projects (layers), graph (nodes), mind-map, search, AI (sparkle), history (clock), settings (sliders), edit (pencil), export (up-tray), tag, sheet, present, summarize (lines), translate (arrows), document, pin (star), plus, swap, chevron, dots/more, table, todo, callout, undo/redo.

---

## Screens / Views

### 1. Main window — reader/editor (primary; `Sutra Prototype.dc.html`)
**Purpose:** open, read, and edit a document across formats.
**Layout (desktop ≥720px):** vertical stack — Topbar (52px) → Context bar (36px) → Body (flex row). Body = Sidebar (240px) | Content (flex, scrolls) | AI dock (340px, conditional).

- **Topbar** (`--panel`, bottom `1px --border`): sidebar toggle (hamburger, 34px) · vertical divider · **tab strip** (flex, horizontal scroll, scrollbar hidden) · `+` new tab · [desktop] mind-map + Aa buttons · collaborator avatars (26px circles, 2px `--panel` border, −8px overlap: `MK` accent, `JD` `#4a7ba6`, `+3` on `--panel2`) · divider · **search chip** (opens ⌘K; shows "Search" + `⌘K` kbd) · **AI toggle** (sparkle; active = `--accent` fill) · **theme** button · **Open** button (`--accent`, hidden on mobile).
  - **Tab:** 7px 9px, radius 9px, gap 7px. Active = `--card` bg + `1px --border` + `--fg` wt 600; inactive = `--text-muted`, transparent border. Contents: format badge (16px) · name (ellipsis, max 130px) · optional `LIVE` pill (9px 700 `--ok` on `--hover`, dot) for live HTML · dirty dot (7px `--accent`) · close `×`.
- **Context bar** (`--bg`): path segment (`--text-muted`) + filename (`--fg` wt 500) · spacer · **mode segmented control** (`--panel2` track, 2px pad; active seg = `--card` + `--accent` wt 600) · `·` · meta ("7 min read · 1,842 words") · **Saved** (check + `--ok`). Hidden on mobile and in edit mode.
- **Sidebar** (`--panel2`, right `1px --border`): sub-tabs **Contents / Files** (active = `--hover` fill wt 700). 
  - *Contents:* header row `CONTENTS` + reading `%`; **3px progress bar** (`--border` track, `--accent` fill = scroll position); TOC entries indented by heading level (`10 + (level−1)*14` px), active entry = `--accent` + `--hover` bg wt 600, scroll-synced; bottom **"Ask about this doc"** card (`--card`, sparkle tile, subtitle) → opens AI summarize.
  - *Files:* nested tree; folders = folder icon in project color + wt 600; files = format badge (20px) + name `--text-muted`.
- **Content pane** (`--bg`, scrolls, custom thin auto-hiding thumb): document column max-width 720px, padding 44px 30px. Renders per format/mode (below).
- **Edit pill** (bottom-center, dark `#211f1c`, radius 12px): **Read / Edit** (active = `--accent`) and, in edit mode, **Done** (`--accent`). Sits at bottom 20px desktop / 96px mobile.

### 2. Per-format content rendering
- **Markdown / text — Reader:** rendered doc (Newsreader headings, Hanken body, Geist Mono code on `--code-bg`, blockquote = 3px `--accent` left border + italic serif). Headings carry `data-h`/`id` for TOC scroll-sync (active heading = last whose `offsetTop − scrollTop ≤ 90`). Callout = flex row, 10px gap, `--code-bg` fill, `1px --border`, radius 10px. Table = collapsed, `1px --border` cells, header row `--panel`/`--hover`.
- **Markdown — Edit:** `contenteditable` on the rendered doc (max-width 720px). Editor toolbar replaces the context bar (46px, `--panel`): undo/redo · Paragraph block dropdown · B / I / S / inline-code / highlight (`#f5e4a8` via `backColor`) · bullet/numbered lists · insert table · Done. Plus **selection bubble** and **slash menu** (§3).
- **HTML — Live vs Reader** (per-tab, remembered): **Live** runs the page in an isolated cross-origin frame (the prototype shows a Revenue Dashboard: KPI cards `--card`, bar chart using `--accent` with the peak bar in `--ok`); **Reader** strips scripts → headings + TOC + find. Mode segmented shows "Reader / Live"; tab shows `LIVE` pill in live mode.
- **PDF:** page canvases centered on `--panel2`, white pages with `0 8px 24px -12px` shadow; top chip "tap Aa for reading mode" (PDF→Markdown extraction opens in a new tab).
- **PPTX — Presentation mode** (`Aurora Editor.dc.html` §5a): full-screen presenter view — large current slide, next-slide thumbnail, speaker notes, elapsed timer + slide counter, progress dots, ←/→ nav, N notes, F full-screen.
- **Excel:** stacked tables today → sheet tabs + sticky headers + sort/filter (see Aurora comps for direction).

### 3. Editor micro-interactions (Notion-grade)
- **Selection bubble:** appears on non-empty text selection, 48px above selection, centered. Dark `#211f1c`, radius 11px: B / I / S / highlight / divider / AI-sparkle (→ summarize). Buttons use `onMouseDown` + `preventDefault` (keep selection) and `document.execCommand`.
- **Slash menu:** type `/` at a line → filtered block palette 24px below caret (`--panel`, radius 12px, 290px). Items: Heading, To-do list, Table, Callout (extend to the full 17-block set: headings, quote, code, divider, image, math, mermaid, callouts…). Selecting deletes the typed `/query` then inserts the block. First item highlighted `--hover`.
- **Autoformat while typing:** `## `→H2, `- `→bullet, `[] `→to-do, `> `→quote, ` ``` `→code, `1. `→numbered.

### 4. Command palette (⌘K)
Centered overlay 90px from top, width min(560px,90%), `--panel`, radius 16px. Search input (magnifier + `esc` kbd) filters a flat action list; each row = icon tile (`--bg`, `--accent` glyph) + label + mono hint. Arrow keys move highlight (`--hover`), Enter runs, Esc closes. Actions: New document, Toggle mode, Edit, Open AI, Summarize, Mind map, Export PDF, and Theme: <each of the 10>.

### 5. AI companion panel (⌘J / sparkle)
Desktop = 340px right dock (`--panel`, left border); mobile = full-screen bottom sheet with drag handle. Header: sparkle tile (`--accent`) + "Sutra AI" + `on this doc` (mono, right). Messages: user = right-aligned `--hover` bubble (radius `13 13 3 13`); AI = left, `✦ Sutra` label (`--accent` 11px 700), streaming text with a blinking `--accent` caret; completed AI replies show **Insert as note** + **Copy** actions. Quick-action chips: Summarize / Key risks / Concept map. Input row: pill (`--bg`, `1px --border`) + send button (`--accent`, up-arrow). Grounded in the active document; bring-your-own API key in Settings.

### 6. Home / Projects dashboard (`Aurora Editor.dc.html` §3a)
**Purpose:** entry point / library. Left **nav rail** (64px: app mark, Home active, Files, Projects, Graph, spacer, History, Settings, avatar). Main: greeting ("Good afternoon, Maya") + date/stats · ⌘K search field · **New** button. **PROJECTS** section = 3-col cards (top 3px project-color bar, 38px icon tile in tinted project color, name wt 700, "N docs · edited…", 3-segment progress). **JUMP BACK IN** = recents list rows (30px format badge, title, project chip with color dot, timestamp). Right column: **Sutra AI** quick-actions card (warm gradient), **Get documents in** (Open ⌘O / Import dashed rows), **Today** activity feed (colored dots).

### 7. Projects & grouping (sidebar + create; `Aurora Editor.dc.html` §3b, §4a)
- **Sidebar Projects group** above Files: collapsible header, each project = 9px color chip + chevron + name + doc count; expanded shows its docs (indented, `1.5px --border` guide). Tabs get a project-colored bottom underline. Right-click → **Add to project** (checkable list + "New project…"), Add tag, Remove.
- **New-project modal:** live-preview header (icon tile recolors as you choose), Name field (focused, `--accent` ring), 8-swatch **Color** row (selected = ring), 8-icon **Icon** grid, optional Description, Cancel / **Create project**.
- **Model:** Projects = primary org (folder-like, ~1 per doc); Tags = cross-cutting labels. Persistence in **local app data**, never written into `.md` files. Mind-map & graph nodes inherit project color.

### 8. Export dialog (`Aurora Editor.dc.html` §4b)
Modal 720×560. Left = **format list** (PDF selected, HTML self-contained, Markdown, Word, PowerPoint, PNG, EPUB; "pandoc" tag on long-tail formats). Middle = **options** (Theme segmented, Page size segmented, toggles: Include TOC / Syntax-highlight / Page numbers). Right = **live page preview**. Footer: destination path + Cancel / **Export**.

### 9. Settings (`Aurora Editor.dc.html` §2c)
Left nav (Appearance / Reading / AI / Behavior / Profile). Appearance = **theme swatch grid** (10 themes, each a 3-color chip, selected ringed in `--accent`). Reading = content-width segmented (Narrow/Normal/Wide/Full), reading-font segmented (Sans/Serif/Mono), font-size stepper, with a **live type preview** card.

### 10. Visualization (`Aurora Editor.dc.html` §5c, §8)
- **Knowledge graph:** force-directed nodes tinted by **project color** (hub larger, cluster hues), edges `--border`-ish, legend, zoom controls, force / group-by-project toggles.
- **Mind map (⌘M):** collapsible heading/topic tree; export SVG / Mermaid / Markdown outline.

---

## Interactions & Behavior
- **Tabs:** click to switch (remembers scroll/zoom/edit/mode per tab); `×` closes; `+` / ⌘O opens; dirty dot when unsaved; live-reload dot when watched; drag to reorder; at 10+ tabs an overflow chip / tab overview.
- **Modes:** per-tab, remembered — MD: Read↔Edit (⌘E); HTML: Reader↔Live; PDF: Reader (+Aa reading mode).
- **⌘K / ⌘E / ⌘J / ⌘M / ⌘O / ⌘⇧O / ⌘F / ⌘[ ⌘]** shortcuts; **Esc** closes any overlay.
- **Find (⌘F):** in-doc search, match count, next/prev, highlights, replace/replace-all; works in MD, Office, PDF page-text, Reader HTML.
- **AI streaming:** append user msg → typing state → stream reply (blinking caret) → reveal Insert-as-note/Copy. Quick actions seed a prompt.
- **Toast:** bottom-center, `--fg` bg / `--bg` text, auto-dismiss ~1.9s (e.g. "Saved to …", "Exported PDF to ~/Exports/").
- **Responsive (≤720px):** topbar collapses (`☰ · tabs · + · ✦ · ⋯`, extras into overflow); sidebar → slide-in **drawer** + backdrop; AI → full-screen **sheet** (drag handle); bottom nav (Contents / Search / ＋ / AI / Theme); safe-area insets; 44px touch targets; pinch-zoom PDFs/slides.

## State Management
Per the prototype's logic class — mirror in the app's state layer:
- `tabs[]` `{id, name, format, modes[], mode, dirty}`, `activeId`.
- `sidebar` (contents|files), `sidebarOpen`/`drawerOpen`, `aiOpen`.
- `theme` (1 of 10), `palette` + `paletteQuery` + `paletteIndex`, `themeMenu`.
- `isMobile` (from viewport width ≤720), `activeHeading` (scroll-sync).
- `ai[]` messages + `aiTyping` + `aiInput`; `bubble` `{top,left}`; `slash` `{top,left,query,len}`; `toast`.
- **Projects/tags** live in local app data (SQLite/JSON sidecar), keyed by file path — never inside documents. Reading position + session tabs persist across relaunch (toggle in Settings).

## Assets
- **Fonts:** Hanken Grotesk, Newsreader, Geist Mono (Google Fonts / bundle locally for offline).
- **Icons:** the inline-SVG stroke set defined in the design files — copy the paths; no icon-font/emoji dependency.
- **No raster assets** required; all UI is CSS + SVG. Document content/images come from the user's files.

## Files
- `Sutra Prototype.dc.html` — interactive behavioral reference (open in a browser to click through).
- `Aurora Editor.dc.html` — static hi-fi comps for all surfaces (zoomable canvas; option ids `1a`…`5c`).
